﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura, pesoatual;
            double DlPesoIdeal;

            if (double.TryParse(txtbxAltura.Text, out altura) &&
                double.TryParse(txtbxPesoAtual.Text, out pesoatual))
            {
                if (rdbtnMulher.Checked)
                {
                    DlPesoIdeal = (62.1 * altura) - 44.7;
                }
                else
                {
                    DlPesoIdeal = (72.7 * altura) - 58;
                }

                DlPesoIdeal = Math.Round(DlPesoIdeal, 2);

                if (pesoatual < DlPesoIdeal)    
                {
                    MessageBox.Show("Você está abaixo do peso ideal");
                }
                else if (pesoatual == DlPesoIdeal)
                {
                    MessageBox.Show("Você está exatamento no peso ideal");
                }
                else
                {
                    MessageBox.Show("Você está acima do peso ideal");
                }
            }
            else
            {
                MessageBox.Show("Digite dados válidos");
            }
        }
    }
}
