﻿namespace PesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPesoAtual = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.txtbxPesoAtual = new System.Windows.Forms.TextBox();
            this.txtbxAltura = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.rdbtnMulher = new System.Windows.Forms.RadioButton();
            this.rdbtnHomem = new System.Windows.Forms.RadioButton();
            this.grpbxGenero = new System.Windows.Forms.GroupBox();
            this.grpbxGenero.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPesoAtual
            // 
            this.lblPesoAtual.AutoSize = true;
            this.lblPesoAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoAtual.Location = new System.Drawing.Point(57, 46);
            this.lblPesoAtual.Name = "lblPesoAtual";
            this.lblPesoAtual.Size = new System.Drawing.Size(118, 26);
            this.lblPesoAtual.TabIndex = 0;
            this.lblPesoAtual.Text = "Peso Atual";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(57, 107);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(69, 26);
            this.lblAltura.TabIndex = 1;
            this.lblAltura.Text = "Altura";
            // 
            // txtbxPesoAtual
            // 
            this.txtbxPesoAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxPesoAtual.Location = new System.Drawing.Point(211, 40);
            this.txtbxPesoAtual.Name = "txtbxPesoAtual";
            this.txtbxPesoAtual.Size = new System.Drawing.Size(149, 32);
            this.txtbxPesoAtual.TabIndex = 2;
            // 
            // txtbxAltura
            // 
            this.txtbxAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxAltura.Location = new System.Drawing.Point(211, 101);
            this.txtbxAltura.Name = "txtbxAltura";
            this.txtbxAltura.Size = new System.Drawing.Size(149, 32);
            this.txtbxAltura.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(225, 166);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(124, 48);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // rdbtnMulher
            // 
            this.rdbtnMulher.AutoSize = true;
            this.rdbtnMulher.Checked = true;
            this.rdbtnMulher.Location = new System.Drawing.Point(21, 42);
            this.rdbtnMulher.Name = "rdbtnMulher";
            this.rdbtnMulher.Size = new System.Drawing.Size(96, 30);
            this.rdbtnMulher.TabIndex = 5;
            this.rdbtnMulher.TabStop = true;
            this.rdbtnMulher.Text = "Mulher";
            this.rdbtnMulher.UseVisualStyleBackColor = true;
            // 
            // rdbtnHomem
            // 
            this.rdbtnHomem.AutoSize = true;
            this.rdbtnHomem.Location = new System.Drawing.Point(21, 74);
            this.rdbtnHomem.Name = "rdbtnHomem";
            this.rdbtnHomem.Size = new System.Drawing.Size(108, 30);
            this.rdbtnHomem.TabIndex = 6;
            this.rdbtnHomem.Text = "Homem";
            this.rdbtnHomem.UseVisualStyleBackColor = true;
            // 
            // grpbxGenero
            // 
            this.grpbxGenero.Controls.Add(this.rdbtnHomem);
            this.grpbxGenero.Controls.Add(this.rdbtnMulher);
            this.grpbxGenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxGenero.Location = new System.Drawing.Point(425, 40);
            this.grpbxGenero.Name = "grpbxGenero";
            this.grpbxGenero.Size = new System.Drawing.Size(144, 123);
            this.grpbxGenero.TabIndex = 7;
            this.grpbxGenero.TabStop = false;
            this.grpbxGenero.Text = "Gênero";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 256);
            this.Controls.Add(this.grpbxGenero);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtbxAltura);
            this.Controls.Add(this.txtbxPesoAtual);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblPesoAtual);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grpbxGenero.ResumeLayout(false);
            this.grpbxGenero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPesoAtual;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.TextBox txtbxPesoAtual;
        private System.Windows.Forms.TextBox txtbxAltura;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.RadioButton rdbtnMulher;
        private System.Windows.Forms.RadioButton rdbtnHomem;
        private System.Windows.Forms.GroupBox grpbxGenero;
    }
}

