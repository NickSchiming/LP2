﻿namespace CalculoSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFami = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.grpbxSexo = new System.Windows.Forms.GroupBox();
            this.rdbFaminino = new System.Windows.Forms.RadioButton();
            this.rdbMasculino = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.msktxtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.msktxtNumFilhos = new System.Windows.Forms.MaskedTextBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.msktxtAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.msktxtIRPF = new System.Windows.Forms.MaskedTextBox();
            this.msktxtSalarioLiq = new System.Windows.Forms.MaskedTextBox();
            this.msktxtSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.grpbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFunc.Location = new System.Drawing.Point(56, 27);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(183, 26);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome funcionario";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(56, 72);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(135, 26);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salario bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumFilhos.Location = new System.Drawing.Point(56, 120);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(177, 26);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Numero de filhos";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqINSS.Location = new System.Drawing.Point(56, 302);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(149, 26);
            this.lblAliqINSS.TabIndex = 3;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqIRPF.Location = new System.Drawing.Point(56, 355);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(147, 26);
            this.lblAliqIRPF.TabIndex = 4;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFami
            // 
            this.lblSalFami.AutoSize = true;
            this.lblSalFami.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFami.Location = new System.Drawing.Point(56, 407);
            this.lblSalFami.Name = "lblSalFami";
            this.lblSalFami.Size = new System.Drawing.Size(150, 26);
            this.lblSalFami.TabIndex = 5;
            this.lblSalFami.Text = "Salario familia";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiq.Location = new System.Drawing.Point(56, 460);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(149, 26);
            this.lblSalLiq.TabIndex = 6;
            this.lblSalLiq.Text = "Salario liquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescINSS.Location = new System.Drawing.Point(477, 303);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(168, 25);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Descontos INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIRPF.Location = new System.Drawing.Point(477, 356);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(156, 25);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // btnVerifica
            // 
            this.btnVerifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifica.Location = new System.Drawing.Point(238, 176);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(190, 37);
            this.btnVerifica.TabIndex = 9;
            this.btnVerifica.Text = "Verifica desconto";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // grpbxSexo
            // 
            this.grpbxSexo.Controls.Add(this.rdbMasculino);
            this.grpbxSexo.Controls.Add(this.rdbFaminino);
            this.grpbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbxSexo.Location = new System.Drawing.Point(660, 27);
            this.grpbxSexo.Name = "grpbxSexo";
            this.grpbxSexo.Size = new System.Drawing.Size(175, 107);
            this.grpbxSexo.TabIndex = 10;
            this.grpbxSexo.TabStop = false;
            this.grpbxSexo.Text = "Sexo";
            // 
            // rdbFaminino
            // 
            this.rdbFaminino.AutoSize = true;
            this.rdbFaminino.Checked = true;
            this.rdbFaminino.Location = new System.Drawing.Point(28, 30);
            this.rdbFaminino.Name = "rdbFaminino";
            this.rdbFaminino.Size = new System.Drawing.Size(118, 29);
            this.rdbFaminino.TabIndex = 0;
            this.rdbFaminino.TabStop = true;
            this.rdbFaminino.Text = "Feminino";
            this.rdbFaminino.UseVisualStyleBackColor = true;
            // 
            // rdbMasculino
            // 
            this.rdbMasculino.AutoSize = true;
            this.rdbMasculino.Location = new System.Drawing.Point(28, 65);
            this.rdbMasculino.Name = "rdbMasculino";
            this.rdbMasculino.Size = new System.Drawing.Size(128, 29);
            this.rdbMasculino.TabIndex = 1;
            this.rdbMasculino.Text = "Masculino";
            this.rdbMasculino.UseVisualStyleBackColor = true;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlCasado.Location = new System.Drawing.Point(660, 140);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(175, 73);
            this.pnlCasado.TabIndex = 11;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(28, 21);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(105, 29);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            this.ckbxCasado.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // msktxtSalBruto
            // 
            this.msktxtSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtSalBruto.Location = new System.Drawing.Point(263, 69);
            this.msktxtSalBruto.Mask = "999990.00";
            this.msktxtSalBruto.Name = "msktxtSalBruto";
            this.msktxtSalBruto.Size = new System.Drawing.Size(117, 31);
            this.msktxtSalBruto.TabIndex = 12;
            // 
            // msktxtNumFilhos
            // 
            this.msktxtNumFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtNumFilhos.Location = new System.Drawing.Point(263, 117);
            this.msktxtNumFilhos.Mask = "90";
            this.msktxtNumFilhos.Name = "msktxtNumFilhos";
            this.msktxtNumFilhos.Size = new System.Drawing.Size(38, 31);
            this.msktxtNumFilhos.TabIndex = 13;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeFunc.Location = new System.Drawing.Point(263, 24);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(302, 31);
            this.txtNomeFunc.TabIndex = 14;
            // 
            // msktxtAliqINSS
            // 
            this.msktxtAliqINSS.Enabled = false;
            this.msktxtAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtAliqINSS.Location = new System.Drawing.Point(238, 299);
            this.msktxtAliqINSS.Name = "msktxtAliqINSS";
            this.msktxtAliqINSS.Size = new System.Drawing.Size(190, 32);
            this.msktxtAliqINSS.TabIndex = 15;
            // 
            // msktxtIRPF
            // 
            this.msktxtIRPF.Enabled = false;
            this.msktxtIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtIRPF.Location = new System.Drawing.Point(238, 352);
            this.msktxtIRPF.Name = "msktxtIRPF";
            this.msktxtIRPF.Size = new System.Drawing.Size(190, 32);
            this.msktxtIRPF.TabIndex = 16;
            // 
            // msktxtSalarioLiq
            // 
            this.msktxtSalarioLiq.Enabled = false;
            this.msktxtSalarioLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtSalarioLiq.Location = new System.Drawing.Point(238, 457);
            this.msktxtSalarioLiq.Name = "msktxtSalarioLiq";
            this.msktxtSalarioLiq.Size = new System.Drawing.Size(190, 32);
            this.msktxtSalarioLiq.TabIndex = 18;
            // 
            // msktxtSalarioFamilia
            // 
            this.msktxtSalarioFamilia.Enabled = false;
            this.msktxtSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msktxtSalarioFamilia.Location = new System.Drawing.Point(238, 404);
            this.msktxtSalarioFamilia.Name = "msktxtSalarioFamilia";
            this.msktxtSalarioFamilia.Size = new System.Drawing.Size(190, 32);
            this.msktxtSalarioFamilia.TabIndex = 17;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.Color.White;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblDados.Location = new System.Drawing.Point(57, 229);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(77, 20);
            this.lblDados.TabIndex = 21;
            this.lblDados.Text = "LblDados";
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescINSS.Location = new System.Drawing.Point(660, 299);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(175, 32);
            this.txtDescINSS.TabIndex = 22;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(660, 352);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(175, 32);
            this.txtDescIRPF.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 540);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.msktxtSalarioLiq);
            this.Controls.Add(this.msktxtSalarioFamilia);
            this.Controls.Add(this.msktxtIRPF);
            this.Controls.Add(this.msktxtAliqINSS);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.msktxtNumFilhos);
            this.Controls.Add(this.msktxtSalBruto);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.grpbxSexo);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFami);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grpbxSexo.ResumeLayout(false);
            this.grpbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFami;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.GroupBox grpbxSexo;
        private System.Windows.Forms.RadioButton rdbMasculino;
        private System.Windows.Forms.RadioButton rdbFaminino;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.MaskedTextBox msktxtSalBruto;
        private System.Windows.Forms.MaskedTextBox msktxtNumFilhos;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.MaskedTextBox msktxtAliqINSS;
        private System.Windows.Forms.MaskedTextBox msktxtIRPF;
        private System.Windows.Forms.MaskedTextBox msktxtSalarioLiq;
        private System.Windows.Forms.MaskedTextBox msktxtSalarioFamilia;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
    }
}

