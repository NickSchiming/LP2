﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculoSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;


            if (txtNomeFunc.Text == string.Empty)
            {
                MessageBox.Show("O nome do funcionário" + "\" + " + "não pode ser vazio");
            }
            else
            {
                if (!double.TryParse(msktxtSalBruto.Text, out salarioBruto) ||
                    !double.TryParse(msktxtNumFilhos.Text, out numeroFilhos))
                {
                    MessageBox.Show("O Salario bruto e o numero de filhos devem ser numeros");
                }
                else
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salario bruto deve ser maior que 0");
                    else
                    {
                        if (salarioBruto <= 800.47)
                        {
                            msktxtAliqINSS.Text = "7,65%";
                            descontoINSS = (7.65 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 1050)
                        {
                            msktxtAliqINSS.Text = "8,65%";
                            descontoINSS = (8.65 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            msktxtAliqINSS.Text = "9,00%";
                            descontoINSS = (9 / 100) * salarioBruto;
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            msktxtAliqINSS.Text = "11,00%";
                            descontoINSS = (11 / 100) * salarioBruto;
                        }
                        else
                        {
                            msktxtAliqINSS.Text = "teto";
                            descontoINSS = 308.17;
                        }
                        txtDescINSS.Text = descontoINSS.ToString("N2");

                        if (salarioBruto <= 1257.12)
                        {
                            msktxtIRPF.Text = "isento";
                            descontoIRPF = 0;
                        }
                        else if (salarioBruto <= 2512.08)
                        {
                            msktxtIRPF.Text = "15%";
                            descontoIRPF = (15 / 100) * salarioBruto;
                        }
                        else
                        {
                            msktxtIRPF.Text = "27,5%";
                            descontoIRPF = (27.5 / 100) * salarioBruto;
                        }
                        txtDescIRPF.Text = descontoIRPF.ToString("N2");

                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF;

                        if (numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = (22.33 * numeroFilhos);
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = (15.74 * numeroFilhos);
                            else
                                salarioFamilia = 0;
                        }
                        salarioLiquido = salarioLiquido + salarioFamilia;

                        msktxtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                        msktxtSalarioLiq.Text = salarioLiquido.ToString("N2");

                        lblDados.Text = "Os descontos do salário " +
                            (rdbFaminino.Checked ? "da Sra." : "do Sr. ") +
                            txtNomeFunc.Text + "\n" + "que é " +
                            (ckbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") +
                            "\n" + "e que tem " + Convert.ToString(numeroFilhos) + " filho(s) são:";
                    }
                }
            }
        }
    }
}
