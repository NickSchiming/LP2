﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";

            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado " + (x + 1), "Entrada de dados");

                if (int.TryParse(valor, out vetor[x]))
                {
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                }
                else 
                {
                    MessageBox.Show("Número Invalido !");
                    x--;
                }
            }

            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";

            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado " + (x + 1), "Entrada de dados");

                if (!int.TryParse(valor, out vetor[x]))
                {
                    MessageBox.Show("Número Invalido !");
                    x--;
                }
                Array.Reverse(vetor);

                for (x = 0; x < 20; x++)
                    auxiliar += vetor[x] + "\n";

                MessageBox.Show(auxiliar);
            }
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            int x;
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            string aux = "";
            double valor = 0;
            bool y;

            for(x = 0; x < 10; x++)
            {
                y = false;
                while (!y)
                {
                    aux = Interaction.InputBox("Digite a quantidade do produto " + (x + 1), "entrada de dados");
                    if (!double.TryParse(aux, out quantidade[x]))
                    {
                        MessageBox.Show("Número Invalido !");
                    }
                    else
                    {
                        y = true;
                    }
                }

                y = false;
                while (!y)
                {
                    aux = Interaction.InputBox("Digite o preco do produto " + (x + 1), "entrada de dados");
                    if (!double.TryParse(aux, out preco[x]))
                    {
                        MessageBox.Show("Número Invalido !");
                    }
                    else
                    {
                        y = true;
                    }
                }

                for (x = 0; x < 10; x++)
                {
                    valor += quantidade[x] * preco[x];
                }

                MessageBox.Show("A faturamento do mes e " + valor);
            }
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
"Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString("N2"));
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            List<string> alunos = new List<string>(new string[] { "Ana","André","Débora","Fátima",
            "João","Janete","Otávio","Marcelo","Pedro","Thais" });
            string lista = "";

            alunos.Remove("Otávio");
            for (int x = 0; x < 9; x++)
            {
                lista += alunos[x] + "\n";
            }
            MessageBox.Show(lista);
        }

        private void btnEx6_Click(object sender, EventArgs e)
        {
            double[,] media = new double[20,3];
            string auxiliar = "";
            string mediafinal = "";
            double soma = 0;

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (nota + 1) + " do aluno " + (aluno + 1));

                    if (!double.TryParse(auxiliar, out media[aluno, nota]))
                    {
                        MessageBox.Show("Dado Invalido!");
                        nota--;
                    }
                }
                for (int nota = 0; nota < 3; nota++)
                {
                    soma += media[aluno, nota];
                }
                soma /= 3;
                mediafinal += "Aluno " + (aluno+1).ToString() + ": média " + soma.ToString("N1") + "\n";
                soma = 0;
            }
            MessageBox.Show(mediafinal);
        }

        private void btnEx7_Click(object sender, EventArgs e)
        {

        }
    }
}
