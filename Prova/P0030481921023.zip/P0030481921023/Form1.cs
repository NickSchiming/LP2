﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481921023
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[3,4];
            string auxiliar = "";
            double somames,somageral = 0;

            for (int mes = 0; mes < 3; mes++)
            {
                somames = 0; 
                for (int semana = 0; semana < 4; semana++)
                {
                    auxiliar = Interaction.InputBox("Digite o total de vendas da semana " +
                                                   (semana + 1) + " do mês " + (mes + 1),
                                                   "Entrada de vendas");

                    if (!double.TryParse(auxiliar, out matriz[mes, semana]))
                    {
                        MessageBox.Show("Dado invalido, por favor digitar apenas números");
                        semana--;
                    }
                }
                for (int semana = 0; semana < 4; semana++)
                {
                    lstbxVerificar.Items.Add("Total do mês: " + (mes + 1) + " Semana: " + 
                                            (semana + 1) + " R$" + 
                                            matriz[mes, semana].ToString("N2"));
                    somames += matriz[mes, semana];
                }
                somageral += somames;
                lstbxVerificar.Items.Add(">> Total do mês: R$" + somames.ToString("N2"));
                lstbxVerificar.Items.Add("--------------------------------------------");
            }
            lstbxVerificar.Items.Add(">> Total Geral: R$" + somageral.ToString("N2"));
        }
    }
}
