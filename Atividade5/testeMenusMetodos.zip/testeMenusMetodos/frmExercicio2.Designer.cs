﻿namespace testeMenusMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btncomparar = new System.Windows.Forms.Button();
            this.btninsere = new System.Windows.Forms.Button();
            this.btnInsere2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(94, 82);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(94, 114);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(192, 82);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(192, 114);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btncomparar
            // 
            this.btncomparar.Location = new System.Drawing.Point(111, 245);
            this.btncomparar.Name = "btncomparar";
            this.btncomparar.Size = new System.Drawing.Size(75, 53);
            this.btncomparar.TabIndex = 4;
            this.btncomparar.Text = "Comparar";
            this.btncomparar.UseVisualStyleBackColor = true;
            this.btncomparar.Click += new System.EventHandler(this.btncomparar_Click);
            // 
            // btninsere
            // 
            this.btninsere.Location = new System.Drawing.Point(206, 245);
            this.btninsere.Name = "btninsere";
            this.btninsere.Size = new System.Drawing.Size(75, 53);
            this.btninsere.TabIndex = 5;
            this.btninsere.Text = "Insere Palavra 1 na 2";
            this.btninsere.UseVisualStyleBackColor = true;
            this.btninsere.Click += new System.EventHandler(this.btninsere_Click);
            // 
            // btnInsere2
            // 
            this.btnInsere2.Location = new System.Drawing.Point(306, 246);
            this.btnInsere2.Name = "btnInsere2";
            this.btnInsere2.Size = new System.Drawing.Size(75, 52);
            this.btnInsere2.TabIndex = 6;
            this.btnInsere2.Text = "Insere ** na Palavra 1";
            this.btnInsere2.UseVisualStyleBackColor = true;
            this.btnInsere2.Click += new System.EventHandler(this.btnInsere2_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInsere2);
            this.Controls.Add(this.btninsere);
            this.Controls.Add(this.btncomparar);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btncomparar;
        private System.Windows.Forms.Button btninsere;
        private System.Windows.Forms.Button btnInsere2;
    }
}