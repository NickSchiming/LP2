﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testeMenusMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btncomparar_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtpalavra1.Text, txtpalavra2.Text, true) == 0)
                MessageBox.Show("Palavras iguais!");
            else
                MessageBox.Show("Palavras Diferentes!");
                
        }

        private void btninsere_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra2.Text.Length / 2;
            txtpalavra2.Text = txtpalavra2.Text.Substring(0, meio) +
                txtpalavra1.Text + txtpalavra2.Text.Substring(meio, txtpalavra2.Text.Length - meio);
        }

        private void btnInsere2_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra1.Text.Length / 2;
            txtpalavra1.Text = txtpalavra1.Text.Insert(meio, "**");
        }
    }
}
